splunklib.modularinput
----------------------

.. automodule:: splunklib.modularinput

.. autoclass:: Argument
    :members: 

.. autoclass:: Event
    :members: 

.. autoclass:: EventWriter
    :members: 

.. autoclass:: InputDefinition
    :members: 

.. autoclass:: Scheme
    :members: 

.. autoclass:: Script
    :members: 

.. autoclass:: ValidationDefinition
    :members: 
