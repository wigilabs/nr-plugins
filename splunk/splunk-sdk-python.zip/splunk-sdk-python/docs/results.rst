splunklib.results
-----------------

.. automodule:: splunklib.results

.. autoclass:: Message

.. autoclass:: ResultsReader
